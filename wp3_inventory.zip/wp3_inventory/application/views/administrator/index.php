<h2>Data administrator</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>No</th>
              <th>Kode Admin</th>
              <th>Nama Lengkap</th>
              <th>Username</th>
              <th>Terdaftar</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            foreach ($show as $key => $value)
          {
            ?>
            <tr>
              <td><?=$key+1;?></td>
              <td><?=$value->kode_admin;?></td>
              <td><?=$value->nama_admin;?></td>
              <td><?=$value->user_name_admin;?></td>
              <td><?=$value->created_at;?></td>
              <td>
                  <a href="<?=site_url('administrator/edit/'.$value->id);?>" class="btn btn-xs btn-warning">Edit</a>
                  <a href="<?=site_url('administrator/delete/'.$value->id);?>" class="btn btn-xs btn-danger">Hapus</a>
              </td>
            </tr>
            
            <?php
          }
          ?>
          <a href="<?=base_url();?>administrator/add" class="btn btn-xs btn-primary">Tambah</a>
          </tbody>
        </table>
      </div>