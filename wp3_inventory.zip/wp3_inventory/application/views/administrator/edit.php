<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-danger">
				<div class="box-header">
					<h3 class="box-title">Edit Administrator</h3>
				</div>
				<div class="box-body">
					<form action="<?=site_url('administrator/update');?>" method="post" accept-charset="utf-8">

				<input type="hidden" name="id" value="<?=$show->id;?>">
				
						<div class="box-body">
			                <div class="form-group">
			                	<label>Kode Admin</label>
			                	<input type="text" name="kode_admin" class="form-control" value="<?=$show->kode_admin;?>" placeholder="Masukkan kode admin" required="required">
			                </div>
			                <div class="form-group">
			                	<label>Nama Admin</label>
			                	<input type="text" name="nama" class="form-control" value="<?=$show->nama_admin;?>" placeholder="Masukkan nama admin" required="required">
			                </div>
			                <div class="form-group">
			                  <label for="exampleInputtext1">Username Admin</label>
			                  <input type="text" name="user" class="form-control" id="exampleInputtext1" placeholder="Username Admin" value="<?=$show->user_name_admin;?>" required>
			                </div>
			                <div class="form-group">
			                  <label>Password Admin</label>
			                  <input type="text" name="password" class="form-control" id="exampleInputtext1" placeholder="Password Admin" value="<?=$show->pass_admin;?>" required>
			                </div>
						</div>

						<div class="box-footer">
							<button type="button" class="btn btn-default"> <i class="fa fa-arrow-circle-left"></i> Batal</button>
							<button type="submit" class="btn btn-primary pull-right"> <i class="fa fa-repeat"></i> Update</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>