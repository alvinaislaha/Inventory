<section class="content">
	<div class="row">
		<div class="col-sm-12">
			<div class="box box-danger">
				<div class="box-header">
					<h3 class="box-title">Tambah Administrator</h3>
				</div>
				<div class="box-body">
					<form action="<?=site_url('Administrator/create');?>" method="post" accept-charset="utf-8">
						<div class="box-body">
			                <div class="form-group">
			                	<label>Kode Admin</label>
			                	<input type="text" name="kode_admin" class="form-control" value="" placeholder="Masukkan kode Administrator" required="required">
			                </div>
			                <div class="form-group">
			                	<label>Nama Admin</label>
			                	<input type="text" name="nama" class="form-control" value="" placeholder="Masukkan nama Admin" required="required">
			                </div>
			                <div class="form-group">
			                  <label for="exampleInputtext1">Username Admin</label>
			                  <input type="text" name="user" class="form-control" id="exampleInputtext1" placeholder="Masukkan Username Admin" value="" required>
			                </div>
			                <div class="form-group">
			                  <label>Password Admin</label>
			                  <input type="text" name="password" class="form-control" id="exampleInputtext1" placeholder="Masukkan Password Admin" value="" required>
			                </div>
						</div>

						<div class="box-footer">
							<button type="button" class="btn btn-default"> <i class="fa fa-arrow-circle-left"></i> Batal</button>
							<button type="submit" class="btn btn-primary pull-right"> <i class="fa fa-send"></i> Tambah</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>