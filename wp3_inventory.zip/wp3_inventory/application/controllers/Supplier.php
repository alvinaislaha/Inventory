<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supplier extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('Supplier_Model');
		$this->load->model('Administrator_Model');
	}

	public function index()
	{
		$data = [
			"content" => "supplier/index",
			"title" => "Data supplier",
			"show"=>$this->Supplier_Model->read()->result()
		];
		$this->load->view("template/my_template", $data);
	}
	public function add()
	{
		$data =
		[
			'title' => 'Supplier',
			'sub_title' => 'Tambah Supplier',
			'content' => 'supplier/add',
			'show_admin' => $this->Administrator_Model->read()->result()
		];
		$this->load->view('template/my_template', $data);	
	}

	public function create()
	{

		$data = array(
			'kode_supplier' => $this->input->post('kode_supplier'),
			'nama_supplier' => $this->input->post('nama'),
			'no_handphone' => $this->input->post('hp'),
			'no_telepon' => 	$this->input->post('tlp'),
			'nama_kontak' => 	$this->input->post('nama_kontak'),
			'created_at' => date("Y-m-d H:i:s"),
			'administrator_id' => 	$this->input->post('id_admin')
		);


		$create = $this->Supplier_Model->create($data);

		if($create){
			redirect('supplier');
		}else{
			redirect('supplier');
		}

	}

	public function edit($id)
	{
		$data =
		[
			'title' => 'supplier',
			'sub_title' => 'Edit Supplier',
			'content' => 'supplier/edit',
			'show' => $this->Supplier_Model->edit($id)->row(),
			'show_admin' => $this->Administrator_Model->read()->result()
		];
		$this->load->view('template/my_template', $data);		
	}

	public function update()
	{
		
		$id_Supplier = $this->input->post('id');
		
		$kode_supplier = $this->input->post('kode_supplier');
		$nama_supplier = $this->input->post('nama');
		$no_handphone = $this->input->post('hp');
		$no_telepon = $this->input->post('tlp');
		$nama_kontak = $this->input->post('nama_kontak');
		$updated_at = date("Y-m-d H:i:s");
		$administrator_id = $this->input->post('id_admin');

		$data = array(
			'kode_supplier' => $this->input->post('kode_supplier'),
			'nama_supplier' => $this->input->post('nama'),
			'no_handphone' => $this->input->post('hp'),
			'no_telepon' => 	$this->input->post('tlp'),
			'nama_kontak' => 	$this->input->post('nama_kontak'),
			'updated_at' => date("Y-m-d H:i:s"),
			'administrator_id' => 	$this->input->post('id_admin')
		);

		$update = $this->Supplier_Model->update($data, $id_Supplier);

		if($update){
			redirect('Supplier');
		}else{
			redirect('Supplier');
		}		
	}

	public function delete($id)
	{
		$data = array(
			'deleted_at' => date('Y-m-d H:i:s', time())
		);

		$delete = $this->Supplier_Model->delete($data, $id);

		if($delete){
			redirect('Supplier');
		}else{
			redirect('Supplier');
		}	
	}
}