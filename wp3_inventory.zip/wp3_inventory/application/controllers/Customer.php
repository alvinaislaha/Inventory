<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Customer_Model');
		$this->load->model('Administrator_Model');
	}

	public function index()
	{
		$data =
		[
			'title' => 'Customer',
			'sub_title' => 'Daftar Customer',
			'content' => 'customer/index',
			'show' => $this->Customer_Model->index()->result()
		];
		$this->load->view('template/my_template', $data);
	}
	public function add()
	{
		$data =
		[
			'title' => 'Customer',
			'sub_title' => 'Tambah Customer',
			'content' => 'customer/add',
			'show_admin' => $this->Administrator_Model->read()->result()
		];
		$this->load->view('template/my_template', $data);	
	}

	public function create()
	{

		$data = array(
			'kode_customer' => $this->input->post('kode'),
			'nama_customer' => $this->input->post('nama'),
			'no_hp_customer' => $this->input->post('hp'),
			'created_at' => date("Y-m-d H:i:s"),
			'administrator_id' => $this->input->post('id_admin')
		);


		$create = $this->Customer_Model->create($data);

		if($create){
			redirect('customer');
		}else{
			redirect('customer');
		}

	}

	public function edit($id)
	{
		$data =
		[
			'title' => 'Customer',
			'sub_title' => 'Edit Customer',
			'content' => 'customer/edit',
			'show' => $this->Customer_Model->edit($id)->row(),
			'show_admin' => $this->Administrator_Model->read()->result()
		];
		$this->load->view('template/my_template', $data);		
	}

	public function update()
	{
		
		$id_customer = $this->input->post('id_customer');
		
		$kode_customer = $this->input->post('kode');
		$nama_customer = $this->input->post('nama');
		$no_hp_customer = $this->input->post('hp');
		$updated_at = date("Y-m-d H:i:s");
		$administrator = $this->input->post('id_admin');

		$data = array(
			'kode_customer' => $kode_customer,
			'nama_customer' => $nama_customer,
			'no_hp_customer' => $no_hp_customer,
			'updated_at' => $updated_at,
			'administrator_id' => $administrator
		);

		$update = $this->Customer_Model->update($data, $id_customer);

		if($update){
			redirect('customer');
		}else{
			redirect('customer');
		}		
	}

	public function delete($id)
	{
		$data = array(
			'deleted_at' => date('Y-m-d H:i:s', time())
		);

		$delete = $this->Customer_Model->delete($data, $id);

		if($delete){
			redirect('customer');
		}else{
			redirect('customer');
		}	
	}
}