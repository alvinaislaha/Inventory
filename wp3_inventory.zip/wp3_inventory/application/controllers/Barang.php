<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Administrator_Model');
		$this->load->model('Supplier_Model');
		$this->load->model('Barang_Model');
	}

	public function index()
	{
		$data = [
			"content" => "barang/index",
			"title" => "Data Barang",
			"show"=>$this->Barang_Model->index()->result()
		];
		$this->load->view("template/my_template", $data);
	}
	public function add()
	{
		$data =
		[
			'title' => 'Barang',
			'sub_title' => 'Tambah Barang',
			'content' => 'barang/add',
			'show_admin' => $this->Administrator_Model->read()->result(),
			'show_supplier' => $this->Supplier_Model->read()->result()
		];
		$this->load->view('template/my_template', $data);	
	}

	public function create()
	{

		$data = array(
			'kode_barang' => $this->input->post('kode_barang'),
			'nama_barang' => $this->input->post('nama_barang'),
			'harga_beli' => $this->input->post('harga_beli'),
			'harga_jual' => 	$this->input->post('harga_jual'),
			'stok' => 	$this->input->post('stok'),
			'created_at' => date("Y-m-d H:i:s"),
			'administrator_id' => 	$this->input->post('id_admin'),
			'supplier_id' => 	$this->input->post('id_supplier')
		);


		$create = $this->Barang_Model->create($data);

		if($create){
			redirect('barang');
		}else{
			redirect('barang');
		}
	}
	public function edit($id)
	{
		$data =
		[
			'title' => 'Barang',
			'sub_title' => 'Edit Barang',
			'content' => 'barang/edit',
			'show' => $this->Barang_Model->edit($id)->row()
		];
		$this->load->view('template/my_template', $data);		
	}
public function update()
	{
		
		$id = $this->input->post('id');
		
			$kode_barang = $this->input->post('kode_barang');
			$nama_barang = $this->input->post('nama_barang');
			$harga_beli = $this->input->post('harga_beli');
			$harga_jual = $this->input->post('harga_jual');
			$stok = $this->input->post('stok');
			$created_at = date("Y-m-d H:i:s");
			$administrator_id =	$this->input->post('id_admin');
			$supplier_id = $this->input->post('id_supplier');

		$data = array(
			'kode_barang' => $kode_barang,
			'nama_barang' => $nama_barang,
			'harga_beli' => $harga_beli,
			'harga_jual' => $harga_jual,
			'stok' => $stok,
			'administrator_id' => $id_admin,
			'supplier_id' => $id_supplier
		);

		$update = $this->Barang_Model->update($data, $id);

		if($update){
			redirect('barang');
		}else{
			redirect('barang');
		}
	}		
	public function delete($id)
	{
		$data = array(
			'deleted_at' => date('Y-m-d H:i:s', time())
		);

		$delete = $this->Barang_Model->delete($data, $id);

		if($delete){
			redirect('barang');
		}else{
			redirect('barang');
		}	
	}
}