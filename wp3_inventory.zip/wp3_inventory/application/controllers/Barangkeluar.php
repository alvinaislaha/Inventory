<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barangkeluar extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Administrator_Model');
		$this->load->model('Barangkeluar_Model');
		$this->load->model('Barang_Model');
	}

	public function index()
	{
		$data = [
			"content" => "barang_keluar/index",
			"title" => "Data Barang Keluar",
			"show"=>$this->Barangkeluar_Model->index()->result()
		];
		$this->load->view("template/my_template", $data);
	}
	public function add()
	{
		$data =
		[
			'title' => 'Barang Keluar',
			'sub_title' => 'Tambah Barang Keluar',
			'content' => 'barang_keluar/add'
		];
		$this->load->view('template/my_template', $data);	
	}

	public function create()
	{

		$data = array(
			'harga_jual' => $this->input->post('jual'),
			'tgl_barang_keluar' => 	$this->input->post('tgl'),
			'created_at' => date("Y-m-d H:i:s"),
			'barang_id' => 	$this->input->post('id_barang'),
			'administrator_id' => 	$this->input->post('id_admin')
		);


		$create = $this->Barangmasuk_Model->create($data);

		if($create){
			redirect('barang_keluar');
		}else{
			redirect('barang_keluar');
		}

	}
}