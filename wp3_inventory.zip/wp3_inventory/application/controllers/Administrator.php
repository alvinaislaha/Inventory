<?php
defined('BASEPATH') OR exit ('No direct script access allowed');

class Administrator extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('Administrator_Model');
	}

	public function index()
	{
		$data = [
			"content" => "administrator/index",
			"title" => "Data administrator",
			"show"=>$this->Administrator_Model->read()->result()
		];
		$this->load->view("template/my_template", $data);
	}
	public function add()
	{
		$data =
		[
			'title' => 'Administrator',
			'sub_title' => 'Tambah Administrator',
			'content' => 'administrator/add'
		];
		$this->load->view('template/my_template', $data);	
	}

	public function create()
	{

		$data = array(
			'kode_admin' => $this->input->post('kode_admin'),
			'nama_admin' => $this->input->post('nama'),
			'user_name_admin' => $this->input->post('user'),
			'pass_admin' => 	$this->input->post('password'),
			'created_at' => date("Y-m-d H:i:s")
		);


		$create = $this->Administrator_Model->create($data);

		if($create){
			redirect('administrator');
		}else{
			redirect('administrator');
		}

	}
	public function edit($id)
	{
		$data =
		[
			'title' => 'Administrator',
			'sub_title' => 'Edit Administrator',
			'content' => 'administrator/edit',
			'show' => $this->Administrator_Model->edit($id)->row()
		];
		$this->load->view('template/my_template', $data);		
	}

	public function update()
	{
		
		$id = $this->input->post('id');
		
		$kode_admin = $this->input->post('kode_admin');
		$nama_admin = $this->input->post('nama');
		$user = $this->input->post('user');
		$password = $this->input->post('password');
		$updated_at = date("Y-m-d H:i:s");

		$data = array(
			'kode_admin' => $kode_admin,
			'nama_admin' => $nama_admin,
			'user_name_admin' => $user,
			'pass_admin' => $password,
			'updated_at' => $updated_at
		);

		$update = $this->Administrator_Model->update($data, $id);

		if($update){
			redirect('administrator');
		}else{
			redirect('administrator');
		}
	}		
	public function delete($id)
	{
		$data = array(
			'deleted_at' => date('Y-m-d H:i:s', time())
		);

		$delete = $this->Administrator_Model->delete($data, $id);

		if($delete){
			redirect('administrator');
		}else{
			redirect('Administrator');
		}	
	}

}