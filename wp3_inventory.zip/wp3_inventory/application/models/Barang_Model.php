<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_Model extends CI_Model {
	public function index()
	{
		$this->db->select('*');
		$this->db->from('barang');
		$this->db->join('administrator', 'barang.administrator_id = administrator.id');
		$this->db->join('supplier', 'barang.supplier_id = supplier.id');
		$this->db->where('barang.deleted_at is null', null);
		$this->db->order_by('barang.id');
		return $this->db->get();
	}

	public function create($data)	
	{
		if($this->db->insert('barang', $data))
		{
			return true;
		}else{
			return false;
		}
	}
	public function edit($id)
	{
		$this->db->select('*');
		$this->db->from('barang');
		$this->db->where('id', $id);
		return $this->db->get();	
	}
	public function update($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('barang'))
		{
			return true;
		}else
		{
			return false;
		}
	}
	public function delete($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('barang'))
		{
			return true;
		}else
		{
			return false;
		}

	}
}

