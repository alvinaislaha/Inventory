<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrator_Model extends CI_Model {

	public function create($data)
	{
		if($this->db->insert('administrator', $data))
		{
			return true;
		}else{
			return false;
		}

	}
	public function read()
	{
		$this->db->select('*');
		$this->db->from('administrator');
		$this->db->where('deleted_at is null', null);
		$this->db->order_by('id');
		return $this->db->get();

	}

	public function edit($id)
	{
		$this->db->select('*');
		$this->db->from('administrator');
		$this->db->where('id', $id);
		return $this->db->get();	
	}

	public function update($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('administrator'))
		{
			return true;
		}else
		{
			return false;
		}

	}
	public function delete($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('administrator'))
		{
			return true;
		}else
		{
			return false;
		}

	}
	
}