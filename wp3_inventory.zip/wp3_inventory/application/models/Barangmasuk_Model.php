<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barangmasuk_Model extends CI_Model {
	public function index()
	{
		$this->db->select('*');
		$this->db->from('barang_masuk');
		$this->db->join('administrator', 'barang_masuk.administrator_id = administrator.id');
		$this->db->join('barang', 'barang_masuk.barang_id = barang.id');
		$this->db->where('barang_masuk.deleted_at is null', null);
		$this->db->order_by('barang_masuk.id');
		return $this->db->get();
	}

	public function create($data)	
	{
		if($this->db->insert('barang_masuk', $data))
		{
			return true;
		}else{
			return false;
		}
	}

	public function edit($id)
	{
		$this->db->select('*');
		$this->db->from('barang_masuk');
		$this->db->join('administrator','barang', 'barang.administrator_id = administrator.id', 'barang_masuk.barang_id = barang.id');
		$this->db->where('barang_masuk.id', $id);

		return $this->db->get();	
	}

	public function update($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('barang_masuk'))
		{
			return true;
		}else
		{
			return false;
		}

	}

	public function delete($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('barang_masuk'))
		{
			return true;
		}else
		{
			return false;
		}
		
	}
}

