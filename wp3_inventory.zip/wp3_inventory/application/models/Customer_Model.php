<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_Model extends CI_Model {
	public function index()
	{
		// return $this->db->get('buku');a
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->join('administrator', 'customer.administrator_id = administrator.id');
		$this->db->where('customer.deleted_at is null', null);
		$this->db->order_by('customer.id');
		return $this->db->get();
	}

	public function create($data)	
	{
		if($this->db->insert('customer', $data))
		{
			return true;
		}else{
			return false;
		}
	}

	public function edit($id)
	{
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->join('administrator', 'customer.administrator_id = administrator.id');
		$this->db->where('customer.id', $id);

		return $this->db->get();	
	}

	public function update($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('customer'))
		{
			return true;
		}else
		{
			return false;
		}

	}

	public function delete($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('customer'))
		{
			return true;
		}else
		{
			return false;
		}
		
	}
}

