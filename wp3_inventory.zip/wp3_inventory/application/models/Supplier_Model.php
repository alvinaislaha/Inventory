<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supplier_Model extends CI_Model {
	public function read()
	{
		// return $this->db->get('supplier');a
		$this->db->select('*');
		$this->db->from('supplier');
		$this->db->join('administrator', 'supplier.administrator_id = administrator.id');
		$this->db->where('supplier.deleted_at is null', null);
		$this->db->order_by('supplier.id');
		return $this->db->get();
	}

	public function create($data)	
	{
		if($this->db->insert('supplier', $data))
		{
			return true;
		}else{
			return false;
		}
	}

	public function edit($id)
	{
		$this->db->select('*');
		$this->db->from('supplier');
		$this->db->join('administrator', 'supplier.administrator_id = administrator.id');
		$this->db->where('supplier.id', $id);

		return $this->db->get();	
	}

	public function update($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('supplier'))
		{
			return true;
		}else
		{
			return false;
		}

	}

	public function delete($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('supplier'))
		{
			return true;
		}else
		{
			return false;
		}
		
	}
}