<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barangkeluar_Model extends CI_Model {
	public function index()
	{
		$this->db->select('*');
		$this->db->from('barang_keluar');
		$this->db->join('administrator', 'barang_keluar.administrator_id = administrator.id');
		$this->db->join('barang', 'barang_keluar.barang_id = barang.id');
		$this->db->where('barang_keluar.deleted_at is null', null);
		$this->db->order_by('barang_keluar.id');
		return $this->db->get();
	}

	public function create($data)	
	{
		if($this->db->insert('barang_keluar', $data))
		{
			return true;
		}else{
			return false;
		}
	}

	public function edit($id)
	{
		$this->db->select('*');
		$this->db->from('barang_keluar');
		$this->db->join('administrator','barang', 'barang.administrator_id = administrator.id', 'barang_keluar.barang_id = barang.id');
		$this->db->where('barang_keluar.id', $id);

		return $this->db->get();	
	}

	public function update($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('barang_keluar'))
		{
			return true;
		}else
		{
			return false;
		}

	}

	public function delete($data, $id)
	{
		$this->db->set($data);
		$this->db->where('id', $id);
		if($this->db->update('barang_keluar'))
		{
			return true;
		}else
		{
			return false;
		}
		
	}
}

